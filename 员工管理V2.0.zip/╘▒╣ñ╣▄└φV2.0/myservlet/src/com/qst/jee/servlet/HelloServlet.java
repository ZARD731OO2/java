package com.qst.jee.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 第一HttpServlet
 * URL为http://127.0.0.1:8080/hello
 * value表示访问或请求Servlet的路径
 */
@WebServlet(name="HelloServlet",value ="/hello" )
public class HelloServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("Servlet接受到客户端请求,客户端ip:" + req.getRemoteAddr());
        //向客户端输出一个静态的网页
        resp.setContentType("text/html;charset=UTF-8");
        //获取响应文本打印输出流
        PrintWriter out = resp.getWriter();
        out.print("<html>");
        out.print("<head>");
        out.print("<title>第一个Servlet</title>");
        out.print("</head>");
        out.print("<body>");
        //获取请求参数
        String name= req.getParameter("name");
        if(name==null){
            out.print("<p>请说出您的名字!</p>");
        }else{
            out.print("<h3>你好!"+name+"</h3>");
        }
        out.print("欢迎学习Servlet");
        out.print("</body>");
        out.print("</html>");
    }
}
