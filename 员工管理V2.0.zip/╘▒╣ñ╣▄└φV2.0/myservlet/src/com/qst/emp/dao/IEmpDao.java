package com.qst.emp.dao;

import com.qst.emp.entity.Emp;

import java.util.List;

public interface IEmpDao {
    /**
     * 根据关键字查询员工
     *
     * @return
     */
    List<Emp> queryEmp(String keyword);

    /**
     * 查询所有员工
     *
     * @return
     */
    List<Emp> queryEmp( );

    /**
     * 添加员工
     *
     * @param emp
     * @return
     */
    int insertEmp(Emp emp);

    /**
     * 根据员工ID删除员工信息
     *
     * @param empId
     * @return
     */
    int deleteEmp(int empId);

    /**
     * 根据员工ID查询员工信息
     *
     * @param empId
     * @return
     */
    Emp getEmp(int empId);

    /**
     * 修改员工信息
     *
     * @param emp
     * @return
     */
    int updateEmp(Emp emp);
}
