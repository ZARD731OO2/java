package com.qst.emp.dao;

import com.qst.emp.entity.Dep;

import java.util.List;

public interface IDepDao {
    /***
     *查询所有部门
     * @return
     */
    public List<Dep> queryDep();
}
