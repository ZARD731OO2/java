package com.qst.emp.dao;

import com.qst.emp.entity.Dep;
import com.qst.emp.entity.Emp;
import com.qst.emp.util.DBUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpDaoImpl implements IEmpDao {
    @Override
    public List<Emp> queryEmp(String keyword) {
        List<Emp> empList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            String sql = "select emp_id,emp_no,emp_name,mobile,birthday,sex,salary,dep_id,homeplace from t_emp where  emp_name like ? or mobile like ? or homeplace like ? or emp_no like ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, '%' + keyword + '%');
            ps.setString(2, '%' + keyword + '%');
            ps.setString(3, '%' + keyword + '%');
            ps.setString(4, '%' + keyword + '%');
            rs = ps.executeQuery();
            while (rs.next()) {
                Integer empId = rs.getInt("emp_id");
                String empNo = rs.getString("emp_no");
                String empName = rs.getString("emp_name");
                Integer sex = rs.getInt("sex");
                String mobile = rs.getString("mobile");
                Date birthday = rs.getDate("birthday");
                Integer salary = rs.getInt("salary");
                Integer depId = rs.getInt("dep_id");
                String homeplace = rs.getString("homeplace");
                Emp emp = new Emp();
                emp.setEmpId(empId);
                emp.setEmpName(empName);
                emp.setEmpNo(empNo);
                emp.setMobile(mobile);
                emp.setSex(sex);
                emp.setSalary(salary);
                emp.setDepId(depId);
                emp.setHomeplace(homeplace);
                emp.setBirthday(birthday);
                empList.add(emp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            empList = null;
        }
        DBUtils.close(rs, ps, conn);
        return empList;
    }

    @Override
    public List<Emp> queryEmp() {
        List<Emp> empList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            String sql = "select emp_id,emp_no,emp_name,mobile,birthday,sex,salary,dep_id,homeplace from t_emp";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Integer empId = rs.getInt("emp_id");
                String empNo = rs.getString("emp_no");
                String empName = rs.getString("emp_name");
                Integer sex = rs.getInt("sex");
                String mobile = rs.getString("mobile");
                Date birthday = rs.getDate("birthday");
                Integer salary = rs.getInt("salary");
                Integer depId = rs.getInt("dep_id");
                String homeplace = rs.getString("homeplace");
                Emp emp = new Emp();
                emp.setEmpId(empId);
                emp.setEmpName(empName);
                emp.setEmpNo(empNo);
                emp.setMobile(mobile);
                emp.setSex(sex);
                emp.setSalary(salary);
                emp.setDepId(depId);
                emp.setHomeplace(homeplace);
                emp.setBirthday(birthday);
                empList.add(emp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            empList = null;
        }
        DBUtils.close(rs, ps, conn);
        return empList;
    }

    @Override
    public int insertEmp(Emp emp) {
        int rows = -1;
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtils.getConnection();
            String sql = "insert into t_emp(emp_no,emp_name,mobile,sex,birthday,salary,homeplace,dep_id)values(?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, emp.getEmpNo());
            ps.setString(2, emp.getEmpName());
            ps.setString(3, emp.getMobile());
            ps.setInt(4, emp.getSex());
            ps.setDate(5, new Date(emp.getBirthday().getTime()));
            ps.setInt(6, emp.getSalary());
            ps.setString(7, emp.getHomeplace());
            ps.setInt(8, emp.getDepId());
            rows = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        DBUtils.close(null, ps, conn);
        return rows;
    }

    @Override
    public int deleteEmp(int empId) {
        int rows = -1;
        Connection conn = null;
        Statement s = null;
        try {
            conn = DBUtils.getConnection();
            s = conn.createStatement();
            String sql = "delete from t_emp where emp_id=" + empId;
            rows = s.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
        DBUtils.close(null, s, conn);
        return rows;
    }

    @Override
    public Emp getEmp(int empId) {
        Emp emp = new Emp();
        Connection conn = null;
        Statement s = null;
        ResultSet rs = null;
        try {
            String sql = "select emp_id,emp_no,emp_name,mobile,birthday,sex,salary,e.dep_id,d.dep_name,homeplace from t_emp  e left join t_dep d on e.dep_id=d.dep_id where emp_id=" + empId;
            conn = DBUtils.getConnection();
            s = conn.createStatement();
            rs = s.executeQuery(sql);
            if (rs.next()) {
                String empNo = rs.getString("emp_no");
                String empName = rs.getString("emp_name");
                Integer sex = rs.getInt("sex");
                String mobile = rs.getString("mobile");
                Date birthday = rs.getDate("birthday");
                Integer salary = rs.getInt("salary");
                Integer depId = rs.getInt("dep_id");
                String homeplace = rs.getString("homeplace");
                emp.setEmpId(empId);
                emp.setEmpName(empName);
                emp.setEmpNo(empNo);
                emp.setMobile(mobile);
                emp.setSex(sex);
                emp.setSalary(salary);
                emp.setDepId(depId);
                emp.setHomeplace(homeplace);
                emp.setBirthday(birthday);
                //获取部门名称
                String depName=rs.getString("dep_name");
                Dep dep=new Dep();
                dep.setDepName(depName);
                //设置当前员工所属部门对象
                emp.setDep(dep);
            }
        } catch (Exception e) {
            e.printStackTrace();
            emp = null;
        }
        DBUtils.close(rs, s, conn);
        return emp;
    }

    @Override
    public int updateEmp(Emp emp) {
        int rows = -1;
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtils.getConnection();
            String sql = "update t_emp set emp_name=?,mobile=?,sex=?,birthday=?,salary=?,homeplace=?,dep_id=? where emp_id=? ";
            ps = conn.prepareStatement(sql);
            ps.setString(1, emp.getEmpName());
            ps.setString(2, emp.getMobile());
            ps.setInt(3, emp.getSex());
            ps.setDate(4, new Date(emp.getBirthday().getTime()));
            ps.setInt(5, emp.getSalary());
            ps.setString(6, emp.getHomeplace());
            ps.setInt(7, emp.getDepId());
            ps.setInt(8, emp.getEmpId());
            rows = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        DBUtils.close(null, ps, conn);
        return rows;
    }
}

