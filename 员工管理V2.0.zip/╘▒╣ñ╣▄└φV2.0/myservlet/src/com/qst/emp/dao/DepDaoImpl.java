package com.qst.emp.dao;

import com.qst.emp.entity.Dep;
import com.qst.emp.util.DBUtils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DepDaoImpl implements IDepDao {
    @Override
    public List<Dep> queryDep() {
        List<Dep> depList = new ArrayList<>();
        Connection conn = null;
        Statement s = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            s = conn.createStatement();
            String sql = "select dep_id,dep_no,dep_name from t_dep";
            rs = s.executeQuery(sql);
            while (rs.next()) {
                Integer depId = rs.getInt("dep_id");
                String depNo = rs.getString("dep_no");
                String depName = rs.getString("dep_name");
                Dep dep = new Dep();
                dep.setDepId(depId);
                dep.setDepName(depName);
                dep.setDepNo(depNo);
                depList.add(dep);
            }

        } catch (Exception e) {
            e.printStackTrace();
            depList = null;
        }
        DBUtils.close(rs, s, conn);
        return depList;
    }
}
