package com.qst.emp.util;

import java.sql.*;

/**
 * 数据库连接工具类
 */
public final class DBUtils {
    /**
     * 获取数据库连接
     *
     * @return
     */
    public final static Connection getConnection() {
        try {
            //1.加载驱动类
            Class.forName("com.mysql.jdbc.Driver");
            //2.设置用户名、密码、URL
            String user = "root";
            String password = "";
            String url = "jdbc:mysql://localhost:3306/qst?useUnicode=true&characterEncoding=utf8";
            //3.通过驱动管理器获得数据库连接
            Connection conn = DriverManager.getConnection(url, user, password);
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /**
     * 关闭资源
     *
     * @param rs
     * @param s
     * @param conn
     */
    public final static void close(ResultSet rs, Statement s, Connection conn) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        if (s != null) {
            try {
                s.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
