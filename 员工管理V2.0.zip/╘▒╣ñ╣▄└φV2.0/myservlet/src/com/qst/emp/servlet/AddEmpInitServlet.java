package com.qst.emp.servlet;

import com.qst.emp.dao.DepDaoImpl;
import com.qst.emp.dao.IDepDao;
import com.qst.emp.entity.Dep;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 添加员工前初始化部门数据
 */
@WebServlet("/emp/add_init_data")
public class AddEmpInitServlet extends HttpServlet {

    public AddEmpInitServlet() {
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //加载部门数据
        IDepDao depDao = new DepDaoImpl();
        List<Dep> depList = depDao.queryDep();
        //将部门数据添加到当前请求对象中,当服务器跳转到添加员工页面后,再通过JSTL标签获取部门数据
        req.setAttribute("depList", depList);
        //服务器跳转到添加部门的页面
        req.getRequestDispatcher("/WEB-INF/jsp/add_emp.jsp").forward(req, resp);

    }
}
