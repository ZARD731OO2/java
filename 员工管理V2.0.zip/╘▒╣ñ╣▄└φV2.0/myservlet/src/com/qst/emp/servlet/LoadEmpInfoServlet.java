package com.qst.emp.servlet;

import com.qst.emp.dao.DepDaoImpl;
import com.qst.emp.dao.EmpDaoImpl;
import com.qst.emp.dao.IDepDao;
import com.qst.emp.dao.IEmpDao;
import com.qst.emp.entity.Dep;
import com.qst.emp.entity.Emp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 根据员工ID查询员工详细信息
 */
@WebServlet(urlPatterns = {"/emp/info", "/emp/update_init"})
public class LoadEmpInfoServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int empId = Integer.parseInt(req.getParameter("emp_id"));
        IEmpDao empDao = new EmpDaoImpl();
        Emp emp = empDao.getEmp(empId);
        req.setAttribute("emp", emp);
        //获取请求路径
        String reqPath = req.getRequestURI();
        System.out.println(reqPath);
        if ("/emp/info".equals(reqPath))
        //服务器端跳转到员工详细信息页面
        {
            req.getRequestDispatcher("/WEB-INF/jsp/emp_info.jsp").forward(req, resp);
        } else {
            //查询部门信息
            IDepDao depDao = new DepDaoImpl();
            List<Dep> depList = depDao.queryDep();
            req.setAttribute("depList", depList);
            //服务端跳转到修改员工页面
            req.getRequestDispatcher("/WEB-INF/jsp/update_emp.jsp").forward(req, resp);
        }
    }
}
