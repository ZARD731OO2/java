package com.qst.emp.servlet;

import com.qst.emp.dao.EmpDaoImpl;
import com.qst.emp.dao.IEmpDao;
import com.qst.emp.entity.Emp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 根据关键字查询员工
 */
@WebServlet(value = "/emp/query_by_keword")
public class QueryByKewordServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String keyword = req.getParameter("keyword");
        IEmpDao empDao = new EmpDaoImpl();
        List<Emp> empList;
        if (keyword == null || "".equals(keyword))
            empList = empDao.queryEmp();
        else
            empList = empDao.queryEmp(keyword);
        //将查询到的数据添加当前请求中
        if (empList != null)
            req.setAttribute("empList", empList);
        else
            req.setAttribute("empList", "exp");//设置查询发生异常的标志
        //服务器跳转到query_emp.jsp
        req.getRequestDispatcher("/query_emp.jsp").forward(req, resp);
    }
}
