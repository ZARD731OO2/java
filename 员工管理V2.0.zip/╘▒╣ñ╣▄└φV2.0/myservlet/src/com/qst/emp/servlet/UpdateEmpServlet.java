package com.qst.emp.servlet;

import com.qst.emp.dao.EmpDaoImpl;
import com.qst.emp.dao.IEmpDao;
import com.qst.emp.entity.Emp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 执行修改员工Servlet
 */
@WebServlet("/emp/update")
public class UpdateEmpServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String empNo = req.getParameter("emp_no");
        String empName = req.getParameter("emp_name");
        int sex = Integer.parseInt(req.getParameter("sex"));
        String mobile = req.getParameter("mobile");
        Date birthday;
        try {
            birthday = new SimpleDateFormat("yyyy-MM-dd").parse(req.getParameter("birthday"));
        } catch (ParseException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        String homeplace = req.getParameter("homeplace");
        int salary = Integer.parseInt(req.getParameter("salary"));
        int empId = Integer.parseInt(req.getParameter("emp_id"));
        int depId=Integer.parseInt(req.getParameter("dep_id"));
        Emp emp=new Emp( empId,  empNo,  empName,  mobile,  sex,  birthday,  salary,  depId,  homeplace);
        IEmpDao empDao=new EmpDaoImpl();
        int rows=empDao.updateEmp(emp);
        resp.sendRedirect("/update_emp_result.jsp？rows="+rows);
    }
}
