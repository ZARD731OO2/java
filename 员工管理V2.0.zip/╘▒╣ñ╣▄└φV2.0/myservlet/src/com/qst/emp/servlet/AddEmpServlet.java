package com.qst.emp.servlet;

import com.qst.emp.dao.EmpDaoImpl;
import com.qst.emp.dao.IEmpDao;
import com.qst.emp.entity.Emp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 处理添加员工业务请求
 */
@WebServlet("/emp/add")
public class AddEmpServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        //获取请求参数
        String empNo = req.getParameter("emp_no");
        String empName = req.getParameter("emp_name");
        int sex = Integer.parseInt(req.getParameter("sex"));
        String mobile = req.getParameter("mobile");
        Date birthday = null;
        try {
            birthday = new SimpleDateFormat("yyyy-MM-dd").parse(req.getParameter("birthday"));
        } catch (ParseException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        int salary = Integer.parseInt(req.getParameter("salary"));
        String homeplace = req.getParameter("homeplace");
        int depId=Integer.valueOf(req.getParameter("dep_id"));
        //打包员工数据
        Emp emp = new Emp(null, empNo, empName, mobile, sex, birthday, salary, depId, homeplace);
        //执行DAO方法
        IEmpDao  empDao=new EmpDaoImpl();
        int rows=empDao.insertEmp(emp);
        //重定向到添加结果页面
        resp.sendRedirect("/add_emp_result.jsp?rows="+rows);

    }
}
