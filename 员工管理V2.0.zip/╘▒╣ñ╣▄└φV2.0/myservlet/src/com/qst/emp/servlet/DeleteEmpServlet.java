package com.qst.emp.servlet;

import com.qst.emp.dao.EmpDaoImpl;
import com.qst.emp.dao.IEmpDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 删除员工,根据ID删除
 */
@WebServlet("/emp/delete")
public class DeleteEmpServlet extends HttpServlet {

    public DeleteEmpServlet() {
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int empId = Integer.parseInt(req.getParameter("emp_id"));
        IEmpDao empDao = new EmpDaoImpl();
        int rows = empDao.deleteEmp(empId);
        //重定向删除结果页面
        resp.sendRedirect("/delete_emp_result.jsp?rows=" + rows);
    }
}
